package com.gargi.servicefactory;

import com.gargi.service.IStudentService;
import com.gargi.service.StudentServiceimpl;


//Abstratcion logic of implementation
public class StudentServiceFactory {
   //constructor is made private to avoid object creation
	private StudentServiceFactory() {
		
	}
   private static IStudentService studentService = null;
	
   public static IStudentService getStudentService() {
	   
	   //singleton pattern code
	   if (studentService == null) {
		   studentService = new StudentServiceimpl();
	   }
		   return studentService;
	
   }
   
   
}
