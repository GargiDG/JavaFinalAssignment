package com.gargi.service;

import com.gargi.daofactory.StudentDaoFactory;
import com.gargi.dto.Student;
import com.gargi.persistence.IStudentDAO;

//service layer logic
public class StudentServiceimpl implements IStudentService {
	private IStudentDAO stdDao;

	@Override
	public String addStudent(String sname, Integer sage, String saddress) {
		stdDao = StudentDaoFactory.getStudentDao();
		return stdDao.addStudent(sname, sage, saddress);
	}
	@Override
	public Student searchStudent(Integer sid) {
		stdDao = StudentDaoFactory.getStudentDao();
		return stdDao.searchStudent(sid);
	}
	@Override
	public String updateById(Student student) {
		stdDao = StudentDaoFactory.getStudentDao();
		return stdDao.updateById(student);
	}

	

}
