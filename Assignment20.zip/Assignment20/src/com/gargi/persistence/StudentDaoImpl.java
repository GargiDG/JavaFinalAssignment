package com.gargi.persistence;

import java.io.IOException;

import java.sql.SQLException;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gargi.dto.Student;
import com.gargi.util.HibernateUtil;


public class StudentDaoImpl implements IStudentDAO {
	Session session = HibernateUtil.getSession();
	@Override
	public String addStudent(String sname, Integer sage, String saddress) {
		Transaction transaction = session.beginTransaction();
		boolean flag = false;
		String status = "";

		try {
			if (transaction != null) {
				Student student = new Student();
				student.setSname(sname);
				student.setSage(sage);
				student.setSaddress(saddress);

				session.save(student);
				flag = true;

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
				status = "success";
			} else {
				transaction.rollback();
				status = "failure";
			}
		}
		return status;
	}

	@Override
	public Student searchStudent(Integer sid) {
		Student student = session.get(Student.class, sid);
		if (student != null)
			return student;
		else
			return null;
	}

	@Override
	public String updateById(Student student) {
		Transaction transaction = session.beginTransaction();
		boolean flag = false;
		String status = "";

		try {
			if (transaction != null) {
				session.merge(student);
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
				status = "success";
			} else {
				transaction.rollback();
				status = "failure";
			}
		}

		return status;
	}

	
	
}
