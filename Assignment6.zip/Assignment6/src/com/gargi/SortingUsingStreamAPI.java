package com.gargi;

import java.util.*;
public class SortingUsingStreamAPI {

	public static void main(String[] args) {
		// Creating a list of integers
        List<Integer> list = Arrays.asList(-10, -21, 0, 25, 43);
  
        System.out.println("The sorted stream is : ");
  
        // displaying the stream with elements
        // sorted in natural order
        list.stream().sorted().forEach(System.out::println);

	}

}
