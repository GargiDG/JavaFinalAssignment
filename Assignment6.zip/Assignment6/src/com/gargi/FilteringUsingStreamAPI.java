package com.gargi;
import java.util.*;
public class FilteringUsingStreamAPI {

	public static void main(String[] args) {
		// Creating a list of Integers
        List<Integer> list = Arrays.asList(30, 4, 60, 12, 20);
  
        // Getting a stream consisting of the
        // elements that are divisible by 10
        // Using Stream filter(Predicate predicate)
        System.out.println("After filtering we get :: ");
        list.stream()
            .filter(num -> num % 10 == 0)
            .forEach(System.out::println);
	}

}
