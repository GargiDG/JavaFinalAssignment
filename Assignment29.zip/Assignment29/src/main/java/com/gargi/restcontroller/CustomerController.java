package com.gargi.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gargi.model.Customer;
import com.gargi.model.CustomerModel;
import com.gargi.model.CustomerModelAssembler;
import com.gargi.service.ICustomerService;



@RestController
@RequestMapping("/api/customer")
public class CustomerController {
	@Autowired
	private ICustomerService service;
	
	@Autowired
    private CustomerModelAssembler customerModelAssembler;

    @Autowired
    private PagedResourcesAssembler<Customer> pagedResourcesAssembler;
	
	@GetMapping("/findAll")
	public ResponseEntity<?> displayProductDetails() {

		List<Customer> list = service.fetchAllCustomers();
		return new ResponseEntity<List<Customer>>(list, HttpStatus.OK);

	}
	
	
	 @GetMapping("/findAllByNames")
	    public List<Customer> fetchCustomersAsFilteredList(@RequestParam(defaultValue = "") String firstNameFilter,
	                                                       @RequestParam(defaultValue = "") String lastNameFilter) {
	        return service.fetchFilteredCustomerDataAsList(firstNameFilter, lastNameFilter);
	    }
	 
	 
	 @GetMapping("/findByPage")
	 public Page<Customer> fetchCustomersWithPageInterface(@RequestParam(defaultValue = "") String firstNameFilter,
             @RequestParam(defaultValue = "") String lastNameFilter,
             @RequestParam(defaultValue = "0") int page,
             @RequestParam(defaultValue = "3") int size) {
return service.fetchCustomerDataAsPageWithFiltering(firstNameFilter, lastNameFilter, page, size);
}

	 
	 @GetMapping("/findByPageSortFilter")
	 public Page<Customer> fetchCustomersWithPageInterfaceAndSorted(@RequestParam(defaultValue = "") String firstNameFilter,
             @RequestParam(defaultValue = "") String lastNameFilter,
             @RequestParam(defaultValue = "0") int page,
             @RequestParam(defaultValue = "3") int size,
             @RequestParam(defaultValue = "") List<String> sortList,
             @RequestParam(defaultValue = "DESC") Sort.Direction sortOrder) {
return service.fetchCustomerDataAsPageWithFilteringAndSorting(firstNameFilter, lastNameFilter, page, size, sortList, sortOrder.toString());
}
	 
	 @GetMapping("/findByPSF")
	 public PagedModel<CustomerModel> fetchCustomersWithPagination(
	            @RequestParam(defaultValue = "") String firstNameFilter,
	            @RequestParam(defaultValue = "") String lastNameFilter,
	            @RequestParam(defaultValue = "0") int page,
	            @RequestParam(defaultValue = "3") int size,
	            @RequestParam(defaultValue = "") List<String> sortList,
	            @RequestParam(defaultValue = "DESC") Sort.Direction sortOrder) {
	        Page<Customer> customerPage = service.fetchCustomerDataAsPageWithFilteringAndSorting(firstNameFilter, lastNameFilter, page, size, sortList, sortOrder.toString());
	        // Use the pagedResourcesAssembler and customerModelAssembler to convert data to PagedModel format
	        return pagedResourcesAssembler.toModel(customerPage, customerModelAssembler);
	    }
	 
}
