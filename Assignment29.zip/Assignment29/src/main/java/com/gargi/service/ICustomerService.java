package com.gargi.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;

import com.gargi.model.Customer;

public interface ICustomerService {

	public List<Customer> fetchAllCustomers();
	public List<Customer> fetchFilteredCustomerDataAsList(String firstNameFilter, String lastNameFilter);
	public Page<Customer> fetchCustomerDataAsPageWithFiltering(String firstNameFilter, String lastNameFilter, int page, int size);
	public Page<Customer> fetchCustomerDataAsPageWithFilteringAndSorting
	(String firstNameFilter, String lastNameFilter, 
			int page, int size, List<String> sortList, String sortOrder);
	
	

}
