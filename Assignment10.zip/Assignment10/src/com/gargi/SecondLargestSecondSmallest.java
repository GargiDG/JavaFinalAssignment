package com.gargi;
import java.util.*;
public class SecondLargestSecondSmallest {
	
	public static void main(String[] args) {

        List<Integer> l = new ArrayList<>();
        System.out.println("How many elements needed to be added in the list? ");
        Scanner sc = new Scanner(System.in);
        int numOfElements = sc.nextInt();
        for (int i=0; i<numOfElements; i++) {
        	System.out.println("Please enter the number: ");
        int value = sc.nextInt();	
        l.add(value);	
        }       
        System.out.println(l);
        
       Collections.sort(l);
       int secondLargest = l.get(numOfElements-2);
        System.out.println("The second largest elelment in the list is :: "+secondLargest);
       int secondSmallest = l.get(1);
       System.out.println("The second smallest  elelment in the list is :: "+secondSmallest);
       
       sc.close();
       
}
}