package com.gargi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gargi.entity.Tourist;
import com.gargi.exception.TouristNotFoundException;
import com.gargi.repository.ITouristRepo;
@Service
public class TouristMgmtServiceImpl implements ITouristMgmtService {

	@Autowired
	private ITouristRepo repo;
	

	

	@Override
	public String registerTourist(Tourist tourist) {
		Integer tid = repo.save(tourist).getTid();
		return "Tourist is registerd having the ticket id :: " + tid;
	}

	@Override
	public List<Tourist> fetchAllTourist() {
		List<Tourist> list = repo.findAll();
		list.sort((t1, t2) -> t1.getTid().compareTo(t2.getTid()));
		return list;
	}

	@Override
	public Tourist fetchTouristById(Integer id) {
		
		return repo.findById(id)
				.orElseThrow(() -> new TouristNotFoundException("tourist with id :: " + id + " not found"));
	}

	

}
