package com.gargi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment25WithAopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment25WithAopApplication.class, args);
	}

}
