package com.gargi.daofactory;

import com.gargi.persistence.IStudentDAO;
import com.gargi.persistence.StudentDaoImpl;

public class StudentDaoFactory {

	
	private StudentDaoFactory() {
		
	}
	
	private static IStudentDAO studentDao= null;
	public static IStudentDAO getStudentDao() {
		if(studentDao==null) {
			studentDao = new StudentDaoImpl();
		}
		return studentDao;
	}
	
}
