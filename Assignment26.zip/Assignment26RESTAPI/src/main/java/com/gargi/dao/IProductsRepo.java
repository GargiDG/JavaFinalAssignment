package com.gargi.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gargi.model.Products;

public interface IProductsRepo extends JpaRepository<Products, Integer> {

}
