package com.gargi.service;

import java.util.List;

import com.gargi.model.Products;

public interface IProductsService {


	
	public String addProduct(Products prod);
	public List<Products> fetchAllProducts();
	public Products fetchProductById(Integer id);
	public String updateProductByDetails(Products prod);
	public String updateProductById(Integer id,Float hikePercent);
	public String deleteProductById(Integer id);	
	
}
