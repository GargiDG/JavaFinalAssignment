package com.gargi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gargi.dao.IProductsRepo;
import com.gargi.exception.ProductNotFoundException;
import com.gargi.model.Products;

@Service
public class ProductsServiceImpl implements IProductsService {
    @Autowired
	private IProductsRepo repo;
	
	@Override
	public String addProduct(Products prod) {
		Integer id = repo.save(prod).getId();
		return "Product is added with the generated id :: " + id;
	}

	@Override
	public List<Products> fetchAllProducts() {
		List<Products> list = repo.findAll();
		list.sort((t1, t2) -> t1.getId().compareTo(t2.getId()));
		return list;
	}

	@Override
	public Products fetchProductById(Integer id) {
		return repo.findById(id)
				.orElseThrow(() -> new ProductNotFoundException("product with id :: " + id + " not found"));
	}

	@Override
	public String updateProductByDetails(Products prod) {
		Optional<Products> optional = repo.findById(prod.getId());
		if (optional.isPresent()) {
			repo.save(prod); // save() performs both insert and update depends on id value
			return "Product with the id ::" + prod.getId() + " updated";
		} else {
			throw new ProductNotFoundException(
					"product with the id:: " + prod.getId() + " not available for updation");
		}
	}

	@Override
	public String updateProductById(Integer id, Float hikePercent) {
		Optional<Products> optional = repo.findById(id);
		if (optional.isPresent()) {
			Products prod = optional.get();
			prod.setPrice(prod.getPrice()+(prod.getPrice()*(hikePercent / 100)));
			repo.save(prod);
			return "Product price is updated for the id :: " + prod.getId();
		} else {
			throw new ProductNotFoundException("product not found for the id " + id);
		}
	}

	@Override
	public String deleteProductById(Integer id) {
		Optional<Products> optional = repo.findById(id);
		if (optional.isPresent()) {
			repo.delete(optional.get());
			return "Product with the id :: " + id + " deleted...";
		} else {
			throw new ProductNotFoundException("Product not found for the id " + id);
		}
	}

}
