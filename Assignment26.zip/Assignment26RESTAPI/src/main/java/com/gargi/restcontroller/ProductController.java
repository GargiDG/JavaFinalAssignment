package com.gargi.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gargi.model.Products;
import com.gargi.service.IProductsService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/product")
public class ProductController {
	@Autowired
	private IProductsService service;
	
	@PostMapping("/add")
	//@ApiOperation("For Products Addition")
	public ResponseEntity<String> addProducts(@RequestBody Products prod) {

		String resultMsg = service.addProduct(prod);
		return new ResponseEntity<String>(resultMsg, HttpStatus.OK);

	}

	@GetMapping("/findAll")
	public ResponseEntity<?> displayProductDetails() {

		List<Products> list = service.fetchAllProducts();
		return new ResponseEntity<List<Products>>(list, HttpStatus.OK);

	}

	@GetMapping("/find/{id}")
	public ResponseEntity<?> displayProductsById(@PathVariable("id") Integer id) {

		Products prod = service.fetchProductById(id);
		return new ResponseEntity<Products>(prod, HttpStatus.OK);

	}

	@PutMapping("/modify")
	public ResponseEntity<String> modifyProduct(@RequestBody Products prod) {

		String msg = service.updateProductByDetails(prod);
		return new ResponseEntity<String>(msg, HttpStatus.OK);

	}

	@PatchMapping("/priceModify/{id}/{hike}")
	public ResponseEntity<String> modifyProductPricetById(@PathVariable("id") Integer id,
			@PathVariable("hike") Float hikeAmt) {

		String msg = service.updateProductById(id, hikeAmt);
		return new ResponseEntity<String>(msg, HttpStatus.OK);

	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> removeProductById(@PathVariable("id") Integer id) {
		String msg = service.deleteProductById(id);
		return new ResponseEntity<String>(msg, HttpStatus.OK);
	}

}
