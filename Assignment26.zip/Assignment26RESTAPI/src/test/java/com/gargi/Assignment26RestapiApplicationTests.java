package com.gargi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment26RestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
