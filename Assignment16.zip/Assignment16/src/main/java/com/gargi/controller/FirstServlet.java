package com.gargi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/first")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String sname = request.getParameter("sname");
		String sage = request.getParameter("sage");

		HttpSession session = request.getSession();
		session.setAttribute("sname", sname);
		session.setAttribute("sage", sage);

		PrintWriter out = response.getWriter();
        String name = (String) session.getAttribute("sname");
        System.out.println(name);
		out.println("<html><head><title>Deposit form</title></head>");
		out.println("<body >");
		out.println("<center>");
		out.println("<h1 style='color:blue;'>Details for..."+name+"</h1>");
		out.println("<form method='post'action='" + response.encodeURL("./second") + "'>");
		out.println("<table>");
		out.println("<tr><th>Qualification</th><td><input type='text' name='squal'/></td></tr>");
		out.println("<tr><th>Designation</th><td><input type='text' name='sdesg'/></td></tr>");
		out.println("<tr><th></th><td><input type='submit' value='next'/></td></tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</center>");
		out.println("</body>");
		out.println("</html>");

		out.close();

	}

}
