package com.gargi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gargi.bo.CoronaVaccine;
import com.gargi.dao.ICoronaVaccineRepo;
@Service("service")
public class CoronaServiceImpl implements ICoronaVaccineMgmtService {
	@Autowired
	private ICoronaVaccineRepo repo;

	@Override
	public String registerCoronaVaccine(CoronaVaccine vaccine) {
		CoronaVaccine saveVaccine = null;
		if (vaccine != null) {
			saveVaccine = repo.save(vaccine);
		}
		return saveVaccine != null ? "vaccine registered succesfully with " + saveVaccine.getRegNo()
				: "vaccine registration failed";
	}

}
