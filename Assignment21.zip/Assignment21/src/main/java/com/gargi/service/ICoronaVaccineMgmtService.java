package com.gargi.service;

import com.gargi.bo.CoronaVaccine;

public interface ICoronaVaccineMgmtService {
	
	public String registerCoronaVaccine(CoronaVaccine vaccine);

}
