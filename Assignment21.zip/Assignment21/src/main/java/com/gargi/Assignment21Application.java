package com.gargi;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.gargi.bo.CoronaVaccine;

import com.gargi.service.ICoronaVaccineMgmtService;

@SpringBootApplication
public class Assignment21Application {

	public static void main(String[] args) {
	ApplicationContext factory = 	SpringApplication.run(Assignment21Application.class, args);
	
	ICoronaVaccineMgmtService service = factory.getBean(ICoronaVaccineMgmtService.class);
	CoronaVaccine vaccine =new CoronaVaccine(null, "Covishield", "Serum", "IND", 750.0, 2);
	
	System.out.println(service.registerCoronaVaccine(vaccine));
	
	
	      ((ConfigurableApplicationContext) factory).close();
	}

}
