package com.gargi.dao;

import org.springframework.data.repository.CrudRepository;

import com.gargi.bo.CoronaVaccine;

public interface ICoronaVaccineRepo extends CrudRepository<CoronaVaccine, Long> {

}
