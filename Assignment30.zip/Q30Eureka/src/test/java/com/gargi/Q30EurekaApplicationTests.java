package com.gargi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Q30EurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
