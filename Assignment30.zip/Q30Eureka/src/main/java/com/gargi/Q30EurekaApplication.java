package com.gargi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class Q30EurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Q30EurekaApplication.class, args);
	}

}
