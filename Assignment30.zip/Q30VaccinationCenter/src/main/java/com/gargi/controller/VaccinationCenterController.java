package com.gargi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.gargi.entity.VaccinationCenter;
import com.gargi.model.Citizen;
import com.gargi.model.RequiredResponse;
import com.gargi.repository.IVCRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;



@RestController
@RequestMapping("/vaccinationcenter")
public class VaccinationCenterController {
    @Autowired
	private IVCRepository repo;
    
    @Autowired
    private RestTemplate restTemplate;
    
    public static final String VC_SERVICE="vcService";

	@PostMapping(path ="/add")
	public ResponseEntity<VaccinationCenter> addVCenter(@RequestBody VaccinationCenter vaccinationCenter) {
		
		VaccinationCenter vaccinationCenterAdded = repo.save(vaccinationCenter);
		return new ResponseEntity<>(vaccinationCenterAdded, HttpStatus.OK);
	}
	
	
	@GetMapping(path = "/id/{id}")
	@CircuitBreaker(name =VC_SERVICE,fallbackMethod = "getAllDataBYCenterId")
	public ResponseEntity<RequiredResponse> handleCitizenDownTime(@PathVariable Integer id){
		RequiredResponse requiredResponse =  new RequiredResponse();
		VaccinationCenter center  = repo.findById(id).get();
		requiredResponse.setCenter(center);
		
		List<Citizen> listOfCitizens = restTemplate.getForObject("http://CITIZEN-SERVICE/citizen/id/"+id, List.class);
		requiredResponse.setCitizens(listOfCitizens);
		return new ResponseEntity<RequiredResponse>(requiredResponse, HttpStatus.OK);
	}
	
	
	public ResponseEntity<RequiredResponse> getAllDataBYCenterId(@PathVariable Integer id, Exception e){
		RequiredResponse requiredResponse =  new RequiredResponse();
		VaccinationCenter center  = repo.findById(id).get();
		requiredResponse.setCenter(center);
		
		return new ResponseEntity<RequiredResponse>(requiredResponse, HttpStatus.OK);
	
}
}