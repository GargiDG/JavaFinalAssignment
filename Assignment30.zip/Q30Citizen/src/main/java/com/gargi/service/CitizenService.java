package com.gargi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gargi.entity.Citizen;

import com.gargi.repository.ICitizenRepository;

@Service
public class CitizenService implements ICitizenService {
	@Autowired
	private ICitizenRepository repo;
	
	@Override
	public Citizen saveCitizen(Citizen citizen) {
		return repo.save(citizen);
	}
	@Override
	public List<Citizen> findByVaccinationCenterId(Integer id) {
		List<Citizen> list = repo.findByVaccinationCenterId(id);
		return list;
	}


}
