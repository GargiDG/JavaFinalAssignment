package com.gargi.service;

import java.util.List;

import com.gargi.entity.Citizen;


public interface ICitizenService {
	public Citizen saveCitizen(Citizen citizen);
	public List<Citizen> findByVaccinationCenterId(Integer id);

}
