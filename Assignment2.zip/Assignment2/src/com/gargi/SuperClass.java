package com.gargi;


//Base Class
public class SuperClass {
   public SuperClass() {
	   System.out.println("Super Class Constructor without Parameters");
   }
   
   public SuperClass(int i, int j) {
	   System.out.println("Super Class Constructor with arguments called");
   }
}

