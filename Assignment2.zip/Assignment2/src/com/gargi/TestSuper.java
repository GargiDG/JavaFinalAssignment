package com.gargi;

/*Constructor in java is used to create the instance of the class.
It's name is the same as the class name.
It does not have explicit return type. 
Constructors have no return statements.
Constructor types:
1) Default Constructor
2) No Args Constructor
3) Parameterized Constructor.
Each time an object is created using a new() keyword, at least one constructor (it could be the default constructor)
 is invoked to assign initial values to the data members of the same class. 
A constructor in Java can not be abstract, final, static, or Synchronized.
Access modifiers can be used in constructor declaration to control its access
 i.e which other class can call the constructor.*/


public class TestSuper {

	public static void main(String[] args) {
		ChildClass cc = new ChildClass();

	}

}
