package com.gargi;

public class ChildClass extends SuperClass {

	public ChildClass() {
		super(10,20);
	}
	public ChildClass(int i, int j) {
		System.out.println("Hello from Child Class Constructor");
	}
	
}
