package com.gargi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


@WebServlet("/read")
public class ReadDataFromDB extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();  
		response.setContentType("text/html");  
        out.println("<html><body>");  
        try 
        { 	
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	System.out.println("Driver loaded succesfully....");
			//  Establish the Connection
			String url = "jdbc:mysql:///jdbcdb";
			String user = "root";
			String password = "MyPassword79";
			Connection connection = DriverManager.getConnection(url, user, password);
			System.out.println("CONNECTION object created...");

			//  Create statement Object and send the Query
			Statement statement = connection.createStatement();
			System.out.println("STATEMENT object created...");

			// Execute the Query and Process the resultSet
			String sqlSelectQuery = "select sid,sname,sage,saddress from student";
			ResultSet resultSet = statement.executeQuery(sqlSelectQuery);
			out.println("<h1>Student Table</h1>");
			System.out.println("RESULTSET object created...");
			System.out.println("SID\tSNAME\tSAGE\tSADDRESS");
			out.println("<table border=1 width=50% height=50%>");  
            out.println("<tr><th>StudentId</th><th>StudentName</th><th>Age</th></th><th>Address</th><tr>");  
			while (resultSet.next()) {
				int sid = resultSet.getInt("sid");
				String sname = resultSet.getString("sname");
				int sage = resultSet.getInt("sage");
				String saddress = resultSet.getString("saddress");
				System.out.println(sid + "\t" + sname + "\t" + sage + "\t" + saddress);
				out.println("<tr><td>" + sid + "</td><td>" + sname + "</td><td>" + sage + "</td><td>" + saddress + "</td></tr>");   
			}

			out.println("</table>");  
            out.println("</html></body>");  
            
			//  Close the resources
			resultSet.close();
			statement.close();
			connection.close();
			System.out.println("Closing the resources...");

        
	 }  
    catch (Exception e) 
   {  
    out.println("error");  
}  
	}

}
