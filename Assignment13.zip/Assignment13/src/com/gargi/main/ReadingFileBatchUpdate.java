package com.gargi.main;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.gargi.util.*;
import static java.lang.Integer.parseInt;
public class ReadingFileBatchUpdate {
	public static void main(String[] args) {
         String filePath ="C:\\Users\\user\\finalAssignment\\Assignment13\\src\\employee.csv" ;
         int batchSize = 20;
		// Resources used
		Connection connection = null;
		PreparedStatement pstmt = null;
		//Scanner scanner = null;

		try {
			connection = JdbcUtil.getJdbcConnection();
			connection.setAutoCommit(false);

			String sqlInsertQuery = "insert into emptab(name, age, address, salary) values(?,?,?,?)";
			
			if (connection != null)
				pstmt = connection.prepareStatement(sqlInsertQuery);

		
				   BufferedReader lineReader = new BufferedReader(new FileReader(filePath));
				   String lineText = null;
				   int count = 0;
				   lineReader.readLine();
				   while( (lineText = lineReader.readLine())!=null) {
					   String[] data = lineText.split(",");
					   
					   String name = data[0];
					   String age = data[1];
					   String address = data[2];
					   String salary = data[3];
					   
					   pstmt.setString(1, name);
						pstmt.setInt(2, parseInt(age));
						pstmt.setString(3, address);
						pstmt.setInt(4, parseInt(salary));
						// Query added to batch file
						pstmt.addBatch();
						if(count%batchSize==0) {
	                    // Executing the queries present in batch file
							pstmt.executeBatch();
						}
						
				   }
				   
					lineReader.close();
					pstmt.executeBatch();
					connection.commit();


	
				System.out.println("Records inserted succesfully....");

			

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				JdbcUtil.cleanUp(connection, pstmt, null);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}

	}
}
