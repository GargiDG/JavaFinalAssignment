package com.gargi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gargi.dao.ICustomerRepository;
import com.gargi.model.Customer;

@Service
public class CustomerServiceImpl implements ICustomerService {
	@Autowired
	private ICustomerRepository repo;

	@Override
	public List<Customer> fetchAllCustomers() {
		List<Customer> list = repo.findAll();
		return list;

}
}
