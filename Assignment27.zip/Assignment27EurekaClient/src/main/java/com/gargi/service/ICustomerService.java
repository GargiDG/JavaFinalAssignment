package com.gargi.service;

import java.util.List;

import com.gargi.model.Customer;

public interface ICustomerService {
	public List<Customer> fetchAllCustomers();

}
