package com.gargi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class Assignment27EurekaClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment27EurekaClientApplication.class, args);
	}

}
