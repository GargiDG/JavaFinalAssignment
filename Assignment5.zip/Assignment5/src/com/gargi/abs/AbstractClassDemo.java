package com.gargi.abs;

//Example  of an abstract class
/*
To specify an abstract class abstract keyword is mandatory 
1.We cannot create abstract class object
2.Abstract class can have all methods abstract
3.Abstract class can have both abstract an concrete methods
4.Abstract class can have all methods concrete
5.The child class/sub class of an abstract class either have to implement all abstract methods or
  declare itself as abstract
6. Constructor cannot be made abstract

*/
abstract class AbsLoanClass
{

	abstract public void dispInt();
	
	 public void welcomeNote()
	{
		System.out.println("Welcome to your favourite bank");
	}
}

class HomeLoan extends AbsLoanClass
{

	
	public void dispInt()
	{
	
		System.out.println("Rate of Interest is 12% for HomeLoan");
		
	}
	//abstract public void dispInt();
}
class EducationLoan extends AbsLoanClass
{

	
	public void dispInt() 
	{
		System.out.println("Rate of Interest is 10% for Education Loan");
	}
	
}



public class AbstractClassDemo {

	public static void main(String[] args) {
		//WE CANNOT CREATE  OBJECT OF AN ABSTRACT CLASS
		//AbsLoanClass abs =new AbsLoanClass();
		
		
		AbsLoanClass loan=new HomeLoan();
		
		// we can create ref of abstract class
		loan.dispInt();
		loan.welcomeNote();
		
		AbsLoanClass loan1=new EducationLoan();
		loan1.dispInt();
		loan1.welcomeNote();

	}

}
