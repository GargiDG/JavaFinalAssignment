package com.gargi.inf;
/*Interface corresponds to Service Requirement Specification(SRS) or contract b/w
client and service provider or 100% pure abstract class.
Declaration and implementation of Interface
===========================================
a. Whenever we are implementing an interface it is compulsory for every method of that
interface we should provide implementation otherwise we have to declare class as abstract
class in that case child class is responsible to provide
implementation for remaining methods.
b. Whenever we are implementing an interface method it is compulsory that it should be
declared as public otherwise it would result in
CompileTime Error.*/


public interface Account {
	
	//The methods are by default "abstract and public"
	void withDraw();
	void deposit();
	void checkBalance();
}
