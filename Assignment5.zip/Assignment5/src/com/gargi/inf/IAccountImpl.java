package com.gargi.inf;

public class IAccountImpl implements Account {

	@Override
	public void withDraw() {
		System.out.println("Provided implementation for interface method withdraw()");
	}

	@Override
	public void deposit() {
		System.out.println("Provided implementation for interface method deposit()");
	}

	@Override
	public void checkBalance() {
		System.out.println("Provided implementation for interface method checkBalance()");

	}

	public static void main(String[] args) {
		IAccountImpl acc = new IAccountImpl();
		acc.withDraw();
		acc.deposit();
		acc.checkBalance();

	}

}
