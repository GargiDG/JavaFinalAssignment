package com.gargi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gargi.entity.Tourist;

public interface ITouristRepo extends JpaRepository<Tourist, Integer> {

}
