package com.gargi.service;

import com.gargi.entity.Tourist;

public interface ITouristMgmtService {
	
	Tourist registerTourist(Tourist tourist);
}
