package com.gargi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gargi.entity.Tourist;
import com.gargi.repository.ITouristRepo;
@Service
public class TouristMgmtServiceImpl implements ITouristMgmtService {

	@Autowired
	private ITouristRepo repo;
	
	@Override
	public Tourist registerTourist(Tourist tourist) {
		
		return repo.save(tourist);
	}

}
