package com.gargi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment24Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment24Application.class, args);
	}

}
