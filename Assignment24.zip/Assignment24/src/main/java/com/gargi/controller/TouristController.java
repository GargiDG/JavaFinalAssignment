package com.gargi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gargi.entity.Tourist;
import com.gargi.service.ITouristMgmtService;

@RestController
@RequestMapping("/api/tourist")
public class TouristController {
	@Autowired
	private ITouristMgmtService service;

//        @PostMapping("/register")
//    	public ResponseEntity<Tourist> enrollTourist(@RequestBody Tourist tourist) {
//        	Tourist savedTourist = service.registerTourist(tourist);
//        	 return new ResponseEntity<>(savedTourist, HttpStatus.CREATED);
//    	
//    	}
	
	 @PostMapping("/register")
 	public ResponseEntity<?> enrollTourist(@RequestBody Tourist tourist) {
		 try {
     	Tourist savedTourist = service.registerTourist(tourist);
     	 return new ResponseEntity<Tourist>(savedTourist, HttpStatus.CREATED);
		 }
		 catch(Exception e) {
			 return new ResponseEntity<String>("Problem in saving tourist info", HttpStatus.INTERNAL_SERVER_ERROR);
		 }
 	}
           
        
    }


