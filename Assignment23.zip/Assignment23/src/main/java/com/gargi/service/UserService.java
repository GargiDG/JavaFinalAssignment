package com.gargi.service;

import com.gargi.model.Login;
import com.gargi.model.User;

public interface UserService {

  int register(User user);

  User validateUser(Login login);
}
