package com.gargi.dao;

import com.gargi.model.Login;
import com.gargi.model.User;

public interface UserDao {

  int register(User user);

  User validateUser(Login login);
}
