CREATE DATABASE IF NOT EXISTS jdbcdb;

USE jdbcdb;

DROP TABLE IF EXISTS `jdbcdb`.`users`;

CREATE TABLE `jdbcdb`.`users` (
  `username` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NULL,
  `firstname` VARCHAR(45) NOT NULL,
  `lastname` VARCHAR(45) NULL,
  `email` VARCHAR(45) NULL,
  `address` VARCHAR(45) NULL,
  `phone` BIGINT NULL,
  PRIMARY KEY (`username`));