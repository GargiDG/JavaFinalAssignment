package com.gargi.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gargi.model.Customer;

public interface ICustomerRepository extends JpaRepository<Customer, Integer> {

}
