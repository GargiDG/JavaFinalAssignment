package com.gargi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gargi.model.Customer;
import com.gargi.service.ICustomerService;

@RestController
@RequestMapping("/api/custreg")
@RefreshScope
public class CustomerController {
	@Autowired
	private ICustomerService service;
	@GetMapping("/findAll")
	public ResponseEntity<?> displayProductDetails() {

		List<Customer> list = service.fetchAllCustomers();
		return new ResponseEntity<List<Customer>>(list, HttpStatus.OK);

}
	
}
