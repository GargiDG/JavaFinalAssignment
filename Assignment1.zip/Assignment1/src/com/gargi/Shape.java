package com.gargi;

public interface Shape {

	public void area();
	public void perimeter();
}
