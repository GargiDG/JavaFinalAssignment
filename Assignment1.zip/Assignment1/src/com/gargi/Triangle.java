package com.gargi;

public class Triangle implements Shape {

	@Override
	public void area() {
		double area;
		double height = 10.0;
		double base = 5.0;
		area = (height * base)/2;
		
		System.out.println("Area of the triangle is :" + area);
	}

	@Override
	public void perimeter() {
		
		double perimeter;
		//three sides of a triangle
		double a = 2.0, b = 3.0, c = 5.0;
		perimeter = a+b+c;
		System.out.println("Perimeter of the triangle is :" + perimeter);

	}

}
