package com.gargi;

public class ShapeDemo {

	public static void main(String[] args) {
		Circle circle = new Circle();
		circle.area();
		circle.perimeter();
		
		Triangle triangle = new Triangle();
		triangle.area();
		triangle.perimeter();
		
	}

}
