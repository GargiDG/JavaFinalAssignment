package com.gargi;

public class Circle implements Shape {

	@Override
	public void area() {
		 int radius;
	     double pi = 3.142, area;
	     radius = 10;
	        // calculating the area of the circle
	     area = pi * radius * radius;
	        // printing the area of the circle
	     System.out.println("Area of the circle is :" + area);

	}

	@Override
	public void perimeter() {
		 int radius;
	     double pi = 3.142, perimeter;
	     radius = 10;
	     perimeter = 2 * pi * radius;
	     System.out.println("Perimeter of the circle is :" + perimeter);
	}

}
