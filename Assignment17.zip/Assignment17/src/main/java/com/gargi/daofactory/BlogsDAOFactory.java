package com.gargi.daofactory;

import com.gargi.persistence.BlogsDAOImpl;
import com.gargi.persistence.IBlogsDAO;


public class BlogsDAOFactory {

	private BlogsDAOFactory() {
		
	}
	private static IBlogsDAO blogsDAO = null;
	public static IBlogsDAO getBlogsDAO() {
		if(blogsDAO == null) {
			blogsDAO = new BlogsDAOImpl();
		}
		
		return blogsDAO;
	}
	
	
}
