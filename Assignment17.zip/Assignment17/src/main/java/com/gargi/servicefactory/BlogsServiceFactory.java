package com.gargi.servicefactory;

import com.gargi.service.BlogsServiceImpl;
import com.gargi.service.IBlogsService;


public class BlogsServiceFactory {

	private BlogsServiceFactory() {
		
	}
	private static IBlogsService blogsService = null;
	public static IBlogsService getBlogsService() {
		if(blogsService == null) {
			blogsService = new BlogsServiceImpl();
		}
		return blogsService;
	}
	
	
	
	
}
