package com.gargi.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gargi.dto.Blogs;

import com.gargi.service.IBlogsService;

import com.gargi.servicefactory.BlogsServiceFactory;



@WebServlet("/controller/*")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
        IBlogsService blogsService = BlogsServiceFactory.getBlogsService();
        
		
		System.out.println("Request URI :: " + request.getRequestURI());
		System.out.println("Path info   :: " + request.getPathInfo());

		if (request.getRequestURI().endsWith("addform")) {
			
			String btitle = request.getParameter("btitle");
			String bdesc = request.getParameter("bdesc");
			String bcontent = request.getParameter("bcontent");
			String bname = request.getParameter("bname");

			
			Blogs blog = new Blogs();
			
			blog.setBtitle(btitle);
			blog.setBdesc(bdesc);
			blog.setBcontent(bcontent);
			blog.setBname(bname);
			
			
			String status = blogsService.addBlog(blog);
			
            RequestDispatcher rd = null;
			
			if (status.equals("success")) {
				request.setAttribute("status", "success");
				rd = request.getRequestDispatcher("../insertResult.jsp");
				rd.forward(request, response);
			} else {
				request.setAttribute("status", "failure");
				rd = request.getRequestDispatcher("../insertResult.jsp");
				rd.forward(request, response);
			}
		}
		

		
		
		if (request.getRequestURI().endsWith("searchform")) {
			
			List<Blogs> blogs = blogsService.searchAll();
			request.setAttribute("blogs", blogs);
			
			
			
			RequestDispatcher rd = null;
			rd = request.getRequestDispatcher("../display.jsp");
			rd.forward(request, response);
		}
		
		
		


	}
}
