package com.gargi.dto;

import java.io.Serializable;

public class Blogs implements Serializable {

	private Integer bid;
	private String btitle;
	private String bdesc;
	private String bcontent;
	private String bname;
	
	public Blogs() {
		
	}

	public Integer getBid() {
		return bid;
	}

	public void setBid(Integer bid) {
		this.bid = bid;
	}

	public String getBtitle() {
		return btitle;
	}

	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}

	public String getBdesc() {
		return bdesc;
	}

	public void setBdesc(String bdesc) {
		this.bdesc = bdesc;
	}

	public String getBcontent() {
		return bcontent;
	}

	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	@Override
	public String toString() {
		return "Blogs [bid=" + bid + ", btitle=" + btitle + ", bdesc=" + bdesc + ", bcontent=" + bcontent + ", bname="
				+ bname + "]";
	}
	
	
	
}
