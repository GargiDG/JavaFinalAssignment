package com.gargi.persistence;

import java.util.List;

import com.gargi.dto.Blogs;

public interface IBlogsDAO {

	// operations to be implemented
	   public String addBlog(Blogs blogs);
		public List<Blogs> searchAll();

	
}
