package com.gargi.persistence;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gargi.dto.Blogs;

import com.gargi.util.JdbcUtil;

public class BlogsDAOImpl implements IBlogsDAO {
	 Connection connection = null;
	 PreparedStatement pstmt = null;
	 ResultSet resultSet= null;
	
	@Override
	public String addBlog(Blogs blog) {
		
      String sqlInsertQuery = "insert into blogs(`btitle`,`bdesc`,`bcontent`,`bname`)values(?,?,?,?)";
		
		try {
			connection = JdbcUtil.getJdbcConnection();
			if (connection!=null) {
				pstmt=connection.prepareStatement(sqlInsertQuery);
			}
			if(pstmt!=null) {
				pstmt.setString(1, blog.getBtitle());
				pstmt.setString(2, blog.getBdesc());
				pstmt.setString(3, blog.getBcontent());
				pstmt.setString(4, blog.getBname());
				
				int rowAffected = pstmt.executeUpdate();
				if(rowAffected ==1) {
					return "success";
				}
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return "failure";
		
		
	}

	@Override
	public List<Blogs> searchAll() {
		List<Blogs> blogs = new ArrayList<>();
		String sqlSelectQuery = "select bid,btitle,bdesc,bcontent,bname from blogs";
		Blogs blog= null;
		
			try {
				connection = JdbcUtil.getJdbcConnection();
				if (connection!=null) {
					pstmt=connection.prepareStatement(sqlSelectQuery);
				}
				
				if(pstmt!=null) {
					resultSet=pstmt.executeQuery();
				}
				if(resultSet!=null) {
					
					while (resultSet.next()) {
						blog = new Blogs();
						//copy resultset data to blog object
						blog.setBid(resultSet.getInt(1));
						blog.setBtitle(resultSet.getString(2));
						blog.setBdesc(resultSet.getString(3));
						blog.setBcontent(resultSet.getString(4));
						blog.setBname(resultSet.getString(5));
						blogs.add(blog);
						
					}
					
				}
				
				System.out.println(blogs.size());
			} 
			catch (SQLException | IOException e) {
				
				e.printStackTrace();
			} 
		System.out.println(blogs.size());
         return blogs;
	}

}
