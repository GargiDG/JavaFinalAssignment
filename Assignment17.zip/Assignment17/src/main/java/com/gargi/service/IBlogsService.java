package com.gargi.service;

import java.util.List;

import com.gargi.dto.Blogs;


public interface IBlogsService {
	
	// operations to be implemented
	
	public String addBlog (Blogs blog);
	public List<Blogs> searchAll() ;
	
				

				

}
