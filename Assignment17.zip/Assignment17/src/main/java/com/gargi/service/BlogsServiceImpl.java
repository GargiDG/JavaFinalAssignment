package com.gargi.service;

import java.util.List;

import com.gargi.daofactory.BlogsDAOFactory;
import com.gargi.dto.Blogs;
import com.gargi.persistence.IBlogsDAO;

public class BlogsServiceImpl implements IBlogsService {
	private IBlogsDAO blogsDAO;

	@Override
	public String addBlog(Blogs blog) {
		blogsDAO = BlogsDAOFactory.getBlogsDAO();
		return blogsDAO.addBlog(blog);
	}

	@Override
	public List<Blogs> searchAll() {
		blogsDAO = BlogsDAOFactory.getBlogsDAO();
		return blogsDAO.searchAll();
		
		
	}

}
