package com.gargi;

import java.io.IOException;
import java.util.Scanner;

class MyException extends Exception
{
	/*The given program contains an exception class MyException which throws negative 
	number exception. We have to read a number from user at run time 
	and throw an exception if the the entered number is negative and handle the exception */
	private static final long serialVersionUID = 1L;

public MyException(String str)
 {
  System.out.println(str);
 }
}

public class NegativeNumberException {

	
	
	public static void main(String[] args) throws IOException {
		
		System.out.println("Please enter a number");
		Scanner scan = new Scanner(System.in);
		//while taking input from the user if it is found negative, instead of abrubtly terminating the 
		//program with an error message from the jvm it is caught and handled by the program
		//providing the reason for the exception that
		//has occured due to wrong/unacceptable input from the user
		try {
		int num = scan.nextInt();
		 if(num < 0)
			    throw new MyException("Negative Numbers are not allowed");
		 else 
			 System.out.println("The num is ::" +num);
		}
		catch(MyException m) {
			System.out.println(m);
			
			 
		}
		scan.close();
	}

}
