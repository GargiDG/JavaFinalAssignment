package com.gargi.service;

import com.gargi.entity.User;

public interface IUserOrderService {
	
	public User getOrdersByUser(Integer uid);
	
}
