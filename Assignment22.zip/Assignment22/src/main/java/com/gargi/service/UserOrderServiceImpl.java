package com.gargi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gargi.entity.User;
import com.gargi.repo.UserRepository;
@Service("service")
public class UserOrderServiceImpl implements IUserOrderService {
   
	@Autowired
	private UserRepository repo;
	
	@SuppressWarnings("deprecation")
	@Override
	public User getOrdersByUser(Integer uid) {
		User user = repo.getById(uid);
		
		return user;
	}

}
