package com.gargi.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "orders")
public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer oid;
	private String oName;
	private Double pricae;
	
	public Orders() {
		
	}
	
	public Orders(String oName, Double pricae) {
		super();
		this.oName = oName;
		this.pricae = pricae;
	}
	public Integer getOid() {
		return oid;
	}
	public void setOid(Integer oid) {
		this.oid = oid;
	}
	public String getoName() {
		return oName;
	}
	public void setoName(String oName) {
		this.oName = oName;
	}
	public Double getPricae() {
		return pricae;
	}
	public void setPricae(Double pricae) {
		this.pricae = pricae;
	}
	@Override
	public String toString() {
		return "Orders [oid=" + oid + ", oName=" + oName + ", pricae=" + pricae + "]";
	}
	
	

}
