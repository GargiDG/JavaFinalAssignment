package com.gargi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.dao.DataAccessException;

import com.gargi.entity.User;
import com.gargi.service.IUserOrderService;

@SpringBootApplication
public class Assignment22Application {

	public static void main(String[] args) {
		ApplicationContext factory =SpringApplication.run(Assignment22Application.class, args);
		IUserOrderService service = factory.getBean(IUserOrderService.class);
		

		/*
		 * try { CoronaVaccine vaccine = service.getVaccineById(10L); if (vaccine !=
		 * null) { System.out.println("vaccine details are :: " + vaccine); }else {
		 * System.out.println("Record not available for the given id"); } }
		 * catch(DataAccessException e) { System.out.println(e.getMessage()); }
		 */
		try {
			User user = service.getOrdersByUser(1);
			if(user !=null) {
				System.out.println("order details by user are :: " + user);
			}else {
				System.out.println("Record not available for the given id"); } 
			}
			
		
		catch(DataAccessException e)
		{ System.out.println(e.getMessage()); }
		
		((ConfigurableApplicationContext) factory).close();
	}

}
